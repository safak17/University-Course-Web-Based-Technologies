﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleIntroCharp
{
    
    class A
    {
       

        public void SayHello(string sender)
        {
            Console.WriteLine("Hello from " + sender);
        }

        public virtual void WhoAreYou() {
            Console.WriteLine("I am an A");
        }
        public int x=1;
        public void F()
        {
            Console.WriteLine("F of A");
        }
        public void G()
        {
            Console.WriteLine("G of A");
        }
    }
}
