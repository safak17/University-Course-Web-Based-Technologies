﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleIntroCharp
{
    class B : A
    {
        public override void WhoAreYou()
        {
            Console.WriteLine("I am an B");
        }

        public new  int x=2;
        public new void F()
        {
            Console.WriteLine("F of B");
        }
        public new void G()
        {
            Console.WriteLine("G of B");
        }
    }
}
