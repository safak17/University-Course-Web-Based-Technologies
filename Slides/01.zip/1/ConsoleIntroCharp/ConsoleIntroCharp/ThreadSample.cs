﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleIntroCharp
{

    using System;
    using System.Threading;
    class Printer {
        char ch;
        int sleepTime;
        public Printer(char c, int t)
        {
            ch = c;
            sleepTime = t;
        }
        public void Print()
        {
            for (int i = 0; i < 100; i++)
            {
                Console.Write(ch);
                Thread.Sleep(sleepTime);
            }
        }
    }
    class ThreadSample {
        static void Main2()
        {
            Printer a = new Printer('.', 10);
            Printer b = new Printer('*', 100);
            new Thread(new ThreadStart(a.Print)).Start();
            new Thread(new ThreadStart(b.Print)).Start();
        }
    }
  
}
