﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleIntroCharp
{
    class Program
    {
        //static void Main(string[] args)
        //{
        //    B b = new B();

        //    b.F(); //F of B
        //    b.G(); // G of B

        //    //we takes functions of B that are inherited from A
        //    A a = (A)b;
        //    a.F(); //F of B
        //    a.G(); // G of B



        //    A a2 = new A();
        //    Notifier greetings = new Notifier(a2.SayHello);
        //    greetings("John");

        //    //a.WhoAreYou();
        //}
    }
}
