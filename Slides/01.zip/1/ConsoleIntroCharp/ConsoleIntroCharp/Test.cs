﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleIntroCharp
{
    public delegate void Notifier(string sender);
    class Model {
      
        public event Notifier notifyViews;
        public void Change(string msg)
        {
            notifyViews(msg);
        }
    }
    class View1 {
        public View1(Model m)
        {
            m.notifyViews += new Notifier(this.Update1);
        }
        void Update1(string sender)
        {
            Console.WriteLine(sender + " was changed");
        }
    }
    class View2 {
        public View2(Model m)
        {
            m.notifyViews += new Notifier(this.Update2);
        }
        void Update2(string sender) {
            Console.WriteLine(sender + " was changed");
        }
    }
    class Test {
        static void Main()
        {
            
            Model m = new Model();
            new View1(m);
            new View2(m);

            m.Change("I inform you that View1 and View2 changed");



        }
    }
}
