﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;

public partial class Sahin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Add();
    }
    public void Add()
    {
        OleDbConnection conn = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\Department.mdb");
        OleDbCommand cmd = new OleDbCommand("SELECT * FROM Students WHERE StudentID=10", conn);
        conn.Open();

        int affectedRowNumber = cmd.ExecuteNonQuery();

        Label1.Text = affectedRowNumber.ToString();

        conn.Close();


    }
}