﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Cities : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.QueryString["cityID"] == null)
        {
            Label1.Text = "You have to specify a city ID";
            Label1.Visible = true;
            return;
        }
    }
}
