﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class DisplayDate : System.Web.UI.UserControl
{
    public enum DisplayModeEnum
    {
       
        LongDateFormat,
        ShortDateFormat,
        LongDateAndTimeFormat,
        ShortDateAndTimeFormat
    }

    public DisplayModeEnum DisplayMode { get; set; }

    protected void Page_Load(object sender, EventArgs e)
    {
        UpdateView();
    }

    public void UpdateView()
    {
        switch (this.DisplayMode)
        {
            case DisplayModeEnum.LongDateFormat:
                Label1.Text = "Today is " + DateTime.Now.ToLongDateString();
                break;
            case DisplayModeEnum.ShortDateFormat:
                Label1.Text = "Today is " + DateTime.Now.ToShortDateString();
                break;
            case DisplayModeEnum.LongDateAndTimeFormat:
                Label1.Text = "Today is " + DateTime.Now.ToLongDateString() + " " + DateTime.Now.ToLongTimeString();
                break;
            case DisplayModeEnum.ShortDateAndTimeFormat:
                Label1.Text = "Today is " + DateTime.Now.ToShortDateString() + " " + DateTime.Now.ToShortTimeString();
                break;
            default:
                Label1.Text = "Today is " + DateTime.Now.ToShortDateString();
                break;
        }
    }
}
