﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        DisplayDate1.DisplayMode = DisplayDate.DisplayModeEnum.ShortDateAndTimeFormat;
        DisplayDate1.UpdateView();
        DisplayDate5.DisplayMode = DisplayDate.DisplayModeEnum.ShortDateFormat;
        DisplayDate5.UpdateView();
    }
}
