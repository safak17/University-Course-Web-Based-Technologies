﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;

public partial class Logo : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
        
    {
        Label3.Text +=  "Sahin";
        Panel1.BackColor = Color.FromName(ddlBackColors.SelectedValue);
        Label1.ForeColor = Color.FromName(ddlForeColors.SelectedValue);
        Label1.Font.Name = ddlFonts.SelectedValue;
        switch (rblBorders.SelectedValue)
        {
            case "NotSet":
                Panel1.BorderStyle = BorderStyle.NotSet;
                break;
            case "None":
                Panel1.BorderStyle = BorderStyle.None;
                break;
            case "Dotted":
                Panel1.BorderStyle = BorderStyle.Dotted;
                break;
            case "Dashed":
                Panel1.BorderStyle = BorderStyle.Dashed;
                break;
            case "Solid":
                Panel1.BorderStyle = BorderStyle.Solid;
                break;
            case "Inset":
                Panel1.BorderStyle = BorderStyle.Inset;
                break;
            case "Outset":
                Panel1.BorderStyle = BorderStyle.Outset;
                break;
            case "Groove":
                Panel1.BorderStyle = BorderStyle.Groove;
                break;
            case "Ridge":
                Panel1.BorderStyle = BorderStyle.Ridge;
                break;
            case "Double":
                Panel1.BorderStyle = BorderStyle.Double;
                break;
        }

        Image1.Visible = chkPicture.Checked;

        Label1.Text = tbGreeting.Text;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        
    }
}
