﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Label1.Text += "You are outside the update panel " + "<br/>";
        lblOutsideUpdatePanel.Text = DateTime.Now.ToLongTimeString();
        lblInsideUpdatePanel.Text = DateTime.Now.ToLongTimeString();
    }
    protected void btnOutsideUpdatePanel_Click(object sender, EventArgs e)
    {

    }
    protected void btnTrigger_Click(object sender, EventArgs e)
    {

    }
    protected void btnInsideUpdatePanel_Click(object sender, EventArgs e)
    {

    }
}
