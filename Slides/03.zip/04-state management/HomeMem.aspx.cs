﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Week_05_Member
{


    public partial class Home : System.Web.UI.Page
    {
        public int a = 0;
        protected void Page_Load(object sender, EventArgs e)
        {
            if(this.IsPostBack){
                a += 5;
            }
        }

        protected void btnCounterMem_Click(object sender, EventArgs e)
        {
          
        }

        protected void btnPrint_Click(object sender, EventArgs e)
        {
            lblPrint.Text = this.a.ToString();
        }
    }
}