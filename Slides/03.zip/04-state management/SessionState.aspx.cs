﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Week_05_StateManagement
{
    public partial class SessionState : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {
           
            Session["name"] = TextBox1.Text;

        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            string name = (string)Session["name"];
            if (name != null)
            {
                Label1.Text = name;
            }

        }

        protected void btnRemoveSess_Click(object sender, EventArgs e)
        {
            Session.Abandon();
            Label1.Text = "Session was removed!";
        }
    }
}