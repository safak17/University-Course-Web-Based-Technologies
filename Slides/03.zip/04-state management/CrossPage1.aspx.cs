﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Week_05_StateManagement
{
    public partial class CrossPage1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           

        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            //Session["Username"] = TextBox1.Text;
            //Application["User"] = TextBox2.Text;
            //HttpCookie cookie = new HttpCookie("username");
            //cookie.Value = TextBox1.Text;
            //cookie.Expires = DateTime.Now.AddDays(14);
            //Response.Cookies.Add(cookie);
 // Response.Redirect("CrossPage2.aspx");
        }
    }

}