﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Week_05_StateManagement
{
    public partial class Counter : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            int count = 0;

            if (Application["Counter"] != null)
            {
                count = (int)Application["Counter"];
            }
            count++;
            Application["Counter"] = count;

            lblCounter.Text = Application["Counter"].ToString();
        }
    }

}