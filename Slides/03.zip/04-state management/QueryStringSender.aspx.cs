﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Week_05_StateManagement
{
    public partial class QueryStringSender : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                lstProducts.Items.Add("Samsung C600");
                lstProducts.Items.Add("Siemens S55");
                lstProducts.Items.Add("Nokia 3310");
                lstProducts.Items.Add("Ericsson 688");
                lstProducts.Items.Add("LG Cookie");
            }
        }
        protected void btnViewInformation_Click(object sender, EventArgs e)
        {
            string product = lstProducts.SelectedValue;

            if (chkDetails.Checked)
                Response.Redirect("QueryStringRecipient.aspx?product=" + product + "&mode=full");
            else
                Response.Redirect("QueryStringRecipient.aspx?product=" + product);
        }
    }

}