﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Week_05_StateManagement
{
    public partial class ApplicationState : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Retrieve the current counter value:
            int count = 0;
            if (Application["Counter"] != null)
            {
                count = (int)Application["Counter"];
            }
            // Increment the counter:
            count++;
            // Store the current counter value:
            Application["Counter"] = count;
            lblCounter.Text = count.ToString();

        }
    }
}