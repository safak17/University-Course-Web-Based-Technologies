﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Week_05_StateManagement
{
    public partial class CookieExample : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            HttpCookie cookie = Request.Cookies["StudentInfo"];

            if (cookie != null)
            {
                string fullname = "";
                fullname = (string)cookie["StudentName"];
                Label1.Text = "Welcome " + fullname;
            }
            else
            {
                Label1.Text = "Please give your name!";
            }
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            HttpCookie cookie = new HttpCookie("StudentInfo");
            
            cookie["StudentName"] = tbName.Text;
            cookie.Expires = DateTime.Now.AddDays(1);
            Response.Cookies.Add(cookie);

            Response.Redirect("CookieExample.aspx");
        }
        protected void btnRemoveCookie_Click(object sender, EventArgs e)
        {
            HttpCookie cookie = Request.Cookies["StudentInfo"];

            if (cookie != null)
            {
               
                cookie.Expires = DateTime.Now.AddDays(-5);
                Response.Cookies.Add(cookie);
            }

            Response.Redirect("CookieExample.aspx");
        }

        protected void Page_PreRender(object sender, EventArgs e)
        {
        }

        protected void btnAfter_Click(object sender, EventArgs e)
        {
            HttpCookie cookie = Request.Cookies["StudentInfo"];

            if (cookie != null)
            {
                string fullname = "";
                fullname = (string)cookie["StudentName"];
                Label1.Text = "Welcome " + fullname;
            }
            else
            {
                Label1.Text = "Cookie not exists!";
            }
        }
    }
}