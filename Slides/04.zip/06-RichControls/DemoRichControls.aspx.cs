﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Week5_RichControls
{
    public partial class DemoRichControls : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            Label1.Text = "You have selected: " + Calendar2.SelectedDate.ToLongDateString();
        }
        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
            Label1.Text = "You have selected: " + Calendar2.SelectedDate.ToLongDateString();
        }
        protected void Wizard1_FinishButtonClick(object sender, WizardNavigationEventArgs e)
        {
            Label1.Text = "Your name: " + TextBox1.Text + "<br />Your last name: " + TextBox2.Text + "<br />Your birthday: " + Calendar2.SelectedDate.ToLongDateString();
            Wizard1.Visible = false;
        }
        protected void Button2_Click(object sender, EventArgs e)
        {
            MultiView1.ActiveViewIndex = (MultiView1.ActiveViewIndex + 1) % 4;

        }
    }
}