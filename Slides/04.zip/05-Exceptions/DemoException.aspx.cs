﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Week5_Exceptions
{
    public partial class DemoException : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnDivide_Click(object sender, EventArgs e)
        {
            double result = 0.0;
            try
            {
                result = double.Parse(tbNumber1.Text) / double.Parse(tbNumber2.Text);
                lblDivision.Text = result.ToString();
            }
            catch (Exception ex )
            {
                string msg = ex.Message.ToString();
                Response.Redirect("DefaultError.aspx?errMessage=" + msg );

            }
        }
    }
}